# Changelog

## 3.0.1

* [BUG_FIX] fixed a bug
* [BREAKING] [BUG_FIX] fixed a bug

## 2.3.7

* [BUG_FIX] fixed a bug

## 2.3.6

* [FEATURE] added new feature

## 2.2.6

* [BUG_FIX] emergency bug fix

## 2.2.5

* [PERF] Increased speed
* [BUG_FIX] fixed a bug
* [FEATURE] Added test feature

## 2.1.3

* [BUG_FIX] Fixed some problem

## 2.1.2

* [FEATURE] Added new feature
* [PERF] Increased query performance
* [BUG_FIX] test bug fix
* [BREAKING] [FEATURE] New feature added

## 1.0.0

* [BREAKING] [PERF] Increased performance
* [BUG_FIX] Fixed bug
* [FEATURE] Added test feature.
